//
//  IDigitApp.swift
//  IDigit
//
//  Created by Nikolay Khort on 14.03.2024.
//

import SwiftUI

@main
struct IDigitApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
